##############################################################################
# Telecom ParisTech                                    Jean-Louis Dessalles  #
#                     INF226: Algorithmes et Complexite                      #
# icc.enst.fr/ALG                                          www.dessalles.fr  #
##############################################################################
# 2014

"""	This program samples memory and measures its complexity by compressing the sample
"""

import sys
import os

from NumberCompression import compression


def distText(Text1, Text2):
	#On commence par lire le contenu de Text1
	#Ficher d'environ 60k
	TextSample = open(Text1).read()
	#On calcule la taille du fichier compresse
	CompressedSize1 = compression(TextSample, Text1)
	#On concatene le contenu de Text2 au contenu precedent
	TextSample += open(Text2).read()
	#On calcule la taille du nouveau fichier compresse
	CompressedSize2 = compression(TextSample, Text1+" + "+Text2)
	#On compare les tailles
	print("Compression {1} avec {0} : {2}\n".format(Text1, Text2, CompressedSize2-CompressedSize1))
  
if __name__ == "__main__":	

	
	LArgs = len(sys.argv)	# number of arguments in the command line

	if LArgs == 3:
		try:
			distText(sys.argv[1], sys.argv[2])
		except IOError:
			print('Unable to read %s and %s' % sys.argv[1:])
	else:
		print('Usage:\n %s <file1 to compress> <file2 to compress and compare with file1>' % os.path.basename(sys.argv[0]))
		
